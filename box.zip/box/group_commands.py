import json
import logging
import os
import time
from zlapi.models import *
from concurrent.futures import ThreadPoolExecutor
import threading

# Đường dẫn tới file cấu hình
SETTING_FILE = 'setting.json'

# Khởi tạo logger với cấu hình chi tiết
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - [GROUP_COMMANDS] - %(levelname)s - %(message)s')
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(formatter)
logger.addHandler(stream_handler)

# Khóa để tránh xung đột khi đọc/ghi file
lock = threading.Lock()

def read_settings(uid):
    """Đọc cài đặt từ file setting.json."""
    data_file_path = os.path.join(f"{uid}_{SETTING_FILE}")
    logger.debug(f"Đọc file cấu hình: {data_file_path}")
    with lock:
        try:
            with open(data_file_path, 'r', encoding='utf-8') as file:
                settings = json.load(file)
                logger.debug(f"Đọc thành công cấu hình cho UID: {uid}")
                return settings
        except FileNotFoundError:
            logger.warning(f"Không tìm thấy file cấu hình: {data_file_path}. Trả về cấu hình rỗng.")
            return {}
        except json.JSONDecodeError as e:
            logger.error(f"Lỗi giải mã JSON từ file {data_file_path}: {str(e)}")
            return {}
        except Exception as e:
            logger.error(f"Lỗi không xác định khi đọc file {data_file_path}: {str(e)}")
            return {}

def write_settings(uid, settings):
    """Ghi cài đặt vào file setting.json."""
    data_file_path = os.path.join(f"{uid}_{SETTING_FILE}")
    logger.debug(f"Ghi file cấu hình: {data_file_path}")
    with lock:
        try:
            with open(data_file_path, 'w', encoding='utf-8') as file:
                json.dump(settings, file, ensure_ascii=False, indent=4)
                logger.debug(f"Ghi thành công cấu hình cho UID: {uid}")
        except Exception as e:
            logger.error(f"Lỗi khi ghi file cấu hình {data_file_path}: {str(e)}")
            raise

def retry_operation(func, max_attempts=5, delay=2):
    """Thử lại một thao tác khi gặp lỗi tạm thời."""
    for attempt in range(1, max_attempts + 1):
        try:
            return func()
        except Exception as e:
            logger.warning(f"Thử lần {attempt}/{max_attempts} thất bại: {str(e)}")
            if attempt == max_attempts:
                logger.error(f"Hết số lần thử. Lỗi cuối cùng: {str(e)}")
                raise
            time.sleep(delay)
    return None

def group_on_all(bot, author_id):
    """
    Kích hoạt bot trong tất cả các nhóm mà bot đang tham gia.

    Args:
        bot: Instance của ZaloAPI
        author_id: ID của người dùng gọi lệnh

    Returns:
        str: Thông báo kết quả
    """
    logger.info(f"Bắt đầu xử lý lệnh group_on_all bởi author_id: {author_id}")
    try:
        # Kiểm tra quyền admin
        settings = read_settings(bot.uid)
        admin_bot = settings.get("admin_bot", [])
        if author_id not in admin_bot:
            logger.warning(f"Người dùng {author_id} không có quyền admin bot")
            return "❌ Bạn không phải admin bot!"

        # Lấy danh sách tất cả các nhóm
        logger.debug("Bắt đầu lấy danh sách nhóm từ Zalo API")
        groups_data = retry_operation(lambda: bot.fetchAllGroups())
        logger.debug(f"Dữ liệu raw từ fetchAllGroups: {groups_data}")

        # Xử lý dữ liệu: nếu là Group object, lấy keys từ gridVerMap
        if hasattr(groups_data, 'gridVerMap'):
            group_ids = [key for key in groups_data.gridVerMap.keys() if key.isdigit() and len(key) > 10]
            logger.debug(f"Danh sách ID nhóm từ gridVerMap: {group_ids}")
        else:
            logger.warning("Dữ liệu từ fetchAllGroups không có gridVerMap. Sử dụng groups như list nếu có.")
            group_ids = []
            if isinstance(groups_data, list):
                for group in groups_data:
                    if isinstance(group, str) and group.isdigit() and len(group) > 10:
                        group_ids.append(group)
                    elif hasattr(group, 'id') and str(group.id).isdigit() and len(str(group.id)) > 10:
                        group_ids.append(str(group.id))
            logger.debug(f"Danh sách ID nhóm lọc được: {group_ids}")

        if not group_ids:
            logger.warning("Không tìm thấy ID nhóm hợp lệ nào")
            return "❌ Không tìm thấy nhóm nào hợp lệ từ API!"

        # Lấy danh sách allowed_thread_ids hiện tại
        allowed_thread_ids = set(settings.get('allowed_thread_ids', []))
        activated_groups = []
        failed_groups = []
        total_groups = len(group_ids)

        logger.debug(f"Tổng số ID nhóm cần xử lý: {total_groups}")

        # Hàm xử lý từng nhóm
        def process_group(thread_id):
            group_name = f"Nhóm ID: {thread_id}"
            logger.debug(f"Xử lý nhóm: {group_name}")
            try:
                if thread_id not in allowed_thread_ids:
                    group_info = retry_operation(lambda: bot.fetchGroupInfo(thread_id).gridInfoMap.get(thread_id))
                    if group_info is None:
                        raise ValueError(f"Không lấy được thông tin nhóm {thread_id} - Có thể nhóm không tồn tại hoặc API lỗi")
                    group_name = group_info.name or group_name  # Cập nhật tên nếu có
                    allowed_thread_ids.add(thread_id)
                    logger.info(f"Kích hoạt bot trong nhóm: {group_name}")
                    return f"✅ {group_name}"
                else:
                    logger.debug(f"Nhóm {group_name} đã được bật trước đó")
                    return f"✅ {group_name} - Đã bật trước đó"
            except Exception as e:
                logger.error(f"Lỗi khi xử lý nhóm {group_name}: {str(e)}")
                return f"❌ {group_name}: Lỗi - {str(e)}"

        # Sử dụng ThreadPoolExecutor để xử lý đồng thời
        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(process_group, group_ids))

        # Phân loại kết quả
        for result in results:
            if result.startswith("✅"):
                activated_groups.append(result)
            else:
                failed_groups.append(result)

        # Cập nhật cài đặt
        settings['allowed_thread_ids'] = list(allowed_thread_ids)
        write_settings(bot.uid, settings)
        logger.info(f"Đã cập nhật danh sách allowed_thread_ids: {len(allowed_thread_ids)} nhóm")

        # Tạo thông báo kết quả
        response = f"[🤖BOT {bot.me_name} {bot.version}] Kích hoạt tất cả nhóm:\n"
        if activated_groups:
            response += "\n".join(activated_groups) + "\n"
            logger.debug(f"Các nhóm được kích hoạt: {len(activated_groups)}")
        if failed_groups:
            response += "Các nhóm thất bại:\n" + "\n".join(failed_groups) + "\n"
            logger.debug(f"Các nhóm thất bại: {len(failed_groups)}")
        response += f"➜ Tổng cộng: {len(activated_groups)} nhóm được bật, {len(failed_groups)} nhóm thất bại."
        logger.info(f"Hoàn tất lệnh group_on_all. Kết quả: {len(activated_groups)} thành công, {len(failed_groups)} thất bại")

        return response

    except Exception as e:
        logger.error(f"Lỗi nghiêm trọng trong group_on_all: {str(e)}", exc_info=True)
        return f"❌ Đã xảy ra lỗi khi kích hoạt bot cho tất cả nhóm: {str(e)}"


def group_off_all(bot, author_id):
    """
    Tắt bot trong tất cả các nhóm mà bot đang tham gia.

    Args:
        bot: Instance của ZaloAPI
        author_id: ID của người dùng gọi lệnh

    Returns:
        str: Thông báo kết quả
    """
    logger.info(f"Bắt đầu xử lý lệnh group_off_all bởi author_id: {author_id}")
    try:
        # Kiểm tra quyền admin
        settings = read_settings(bot.uid)
        admin_bot = settings.get("admin_bot", [])
        if author_id not in admin_bot:
            logger.warning(f"Người dùng {author_id} không có quyền admin bot")
            return "❌ Bạn không phải admin bot!"

        # Lấy danh sách tất cả các nhóm
        logger.debug("Bắt đầu lấy danh sách nhóm từ Zalo API")
        groups_data = retry_operation(lambda: bot.fetchAllGroups())
        logger.debug(f"Dữ liệu raw từ fetchAllGroups: {groups_data}")

        # Xử lý dữ liệu: nếu là Group object, lấy keys từ gridVerMap
        if hasattr(groups_data, 'gridVerMap'):
            group_ids = [key for key in groups_data.gridVerMap.keys() if key.isdigit() and len(key) > 10]
            logger.debug(f"Danh sách ID nhóm từ gridVerMap: {group_ids}")
        else:
            logger.warning("Dữ liệu từ fetchAllGroups không có gridVerMap. Sử dụng groups như list nếu có.")
            group_ids = []
            if isinstance(groups_data, list):
                for group in groups_data:
                    if isinstance(group, str) and group.isdigit() and len(group) > 10:
                        group_ids.append(group)
                    elif hasattr(group, 'id') and str(group.id).isdigit() and len(str(group.id)) > 10:
                        group_ids.append(str(group.id))
            logger.debug(f"Danh sách ID nhóm lọc được: {group_ids}")

        if not group_ids:
            logger.warning("Không tìm thấy ID nhóm hợp lệ nào")
            return "❌ Không tìm thấy nhóm nào hợp lệ từ API!"

        # Lấy danh sách allowed_thread_ids hiện tại
        allowed_thread_ids = set(settings.get('allowed_thread_ids', []))
        deactivated_groups = []
        failed_groups = []
        total_groups = len(group_ids)

        logger.debug(f"Tổng số ID nhóm cần xử lý: {total_groups}")

        # Hàm xử lý từng nhóm
        def process_group(thread_id):
            group_name = f"Nhóm ID: {thread_id}"
            logger.debug(f"Xử lý nhóm: {group_name}")
            try:
                if thread_id in allowed_thread_ids:
                    group_info = retry_operation(lambda: bot.fetchGroupInfo(thread_id).gridInfoMap.get(thread_id))
                    if group_info is None:
                        raise ValueError(f"Không lấy được thông tin nhóm {thread_id} - Có thể nhóm không tồn tại hoặc API lỗi")
                    group_name = group_info.name or group_name  # Cập nhật tên nếu có
                    allowed_thread_ids.discard(thread_id)
                    logger.info(f"Tắt bot trong nhóm: {group_name}")
                    return f"✅ {group_name}"
                else:
                    logger.debug(f"Nhóm {group_name} đã tắt trước đó")
                    return f"✅ {group_name} - Đã tắt trước đó"
            except Exception as e:
                logger.error(f"Lỗi khi xử lý nhóm {group_name}: {str(e)}")
                return f"❌ {group_name}: Lỗi - {str(e)}"

        # Sử dụng ThreadPoolExecutor để xử lý đồng thời
        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(process_group, group_ids))

        # Phân loại kết quả
        for result in results:
            if result.startswith("✅"):
                deactivated_groups.append(result)
            else:
                failed_groups.append(result)

        # Cập nhật cài đặt
        settings['allowed_thread_ids'] = list(allowed_thread_ids)
        write_settings(bot.uid, settings)
        logger.info(f"Đã cập nhật danh sách allowed_thread_ids: {len(allowed_thread_ids)} nhóm")

        # Tạo thông báo kết quả
        response = f"[🤖BOT {bot.me_name} {bot.version}] Tắt tất cả nhóm:\n"
        if deactivated_groups:
            response += "\n".join(deactivated_groups) + "\n"
            logger.debug(f"Các nhóm được tắt: {len(deactivated_groups)}")
        if failed_groups:
            response += "Các nhóm thất bại:\n" + "\n".join(failed_groups) + "\n"
        response += f"➜ Tổng cộng: {len(deactivated_groups)} nhóm được tắt, {len(failed_groups)} nhóm thất bại."
        logger.info(f"Hoàn tất lệnh group_off_all. Kết quả: {len(deactivated_groups)} thành công, {len(failed_groups)} thất bại")

        return response

    except Exception as e:
        logger.error(f"Lỗi nghiêm trọng trong group_off_all: {str(e)}", exc_info=True)
        return f"❌ Đã xảy ra lỗi khi tắt bot cho tất cả nhóm: {str(e)}"