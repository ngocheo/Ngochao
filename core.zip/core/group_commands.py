import json
import logging
from zlapi.models import *

# Đường dẫn tới file cấu hình
SETTING_FILE = 'setting.json'

def read_settings(uid):
    """Đọc cài đặt từ file setting.json."""
    data_file_path = os.path.join(f"{uid}_{SETTING_FILE}")
    try:
        with open(data_file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def write_settings(uid, settings):
    """Ghi cài đặt vào file setting.json."""
    data_file_path = os.path.join(f"{uid}_{SETTING_FILE}")
    with open(data_file_path, 'w', encoding='utf-8') as file:
        json.dump(settings, file, ensure_ascii=False, indent=4)

def group_on_all(bot, author_id):
    """
    Kích hoạt bot trong tất cả các nhóm mà bot đang tham gia.

    Args:
        bot: Instance của ZaloAPI
        author_id: ID của người dùng gọi lệnh

    Returns:
        str: Thông báo kết quả
    """
    try:
        # Kiểm tra quyền admin
        settings = read_settings(bot.uid)
        admin_bot = settings.get("admin_bot", [])
        if author_id not in admin_bot:
            return "❌ Bạn không phải admin bot!"

        # Lấy danh sách tất cả các nhóm
        groups = bot.fetchAllGroups()
        if not groups:
            return "❌ Không tìm thấy nhóm nào mà bot đang tham gia!"

        # Lấy danh sách allowed_thread_ids hiện tại
        allowed_thread_ids = set(settings.get('allowed_thread_ids', []))
        activated_groups = []
        failed_groups = []

        # Duyệt qua từng nhóm và kích hoạt bot
        for group in groups:
            thread_id = str(group.id)
            group_name = group.name or "Nhóm không xác định"
            if thread_id not in allowed_thread_ids:
                try:
                    group_info = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
                    allowed_thread_ids.add(thread_id)
                    activated_groups.append(f"✅ {group_name} (ID: {thread_id})")
                except Exception as e:
                    failed_groups.append(f"❌ {group_name} (ID: {thread_id}): Lỗi - {str(e)}")
            else:
                activated_groups.append(f"✅ {group_name} (ID: {thread_id}) - Đã bật trước đó")

        # Cập nhật cài đặt
        settings['allowed_thread_ids'] = list(allowed_thread_ids)
        write_settings(bot.uid, settings)

        # Tạo thông báo kết quả
        response = f"[🤖BOT {bot.me_name} {bot.version}] Kích hoạt tất cả nhóm:\n"
        if activated_groups:
            response += "\n".join(activated_groups) + "\n"
        if failed_groups:
            response += "Các nhóm thất bại:\n" + "\n".join(failed_groups) + "\n"
        response += f"➜ Tổng cộng: {len(activated_groups)} nhóm được bật, {len(failed_groups)} nhóm thất bại."

        return response

    except Exception as e:
        logging.error(f"Error in group_on_all: {e}")
        return f"❌ Đã xảy ra lỗi khi kích hoạt bot cho tất cả nhóm: {str(e)}"